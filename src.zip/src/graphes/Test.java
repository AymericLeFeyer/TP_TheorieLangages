package graphes;


import java.util.Date;

public class Test {
    public static void main(String[] args) {
        Date aujourdhui = new Date();
        System.out.println(aujourdhui);
        System.out.println(aujourdhui.getTime());

    }

}
